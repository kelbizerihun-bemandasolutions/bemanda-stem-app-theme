<?php
// Bemanda front-page layout (v0.1.8).
// Two-brand marketing front page. Moodle's native nav (navbar, user menu,
// drawers, edit mode) is retained via Boost's drawers layout. Below the navbar
// sits a centered brand toggle that switches between two self-contained
// marketing panels: BemandaSTEM (the v0.1.7 design) and Bemanda Solutions
// (professional training). The switch is client-side; no page reload. The
// chosen brand is remembered in a cookie.

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/behat/lib.php');
require_once($CFG->dirroot . '/course/lib.php');

// ---------------------------------------------------------------------------
// Settings: membership CTA (used by the STEM brand header + price card).
// ---------------------------------------------------------------------------
$membershipsetting = trim((string)get_config('theme_bemanda', 'membershipurl'));
if ($membershipsetting === '') {
    $membershipsetting = '/login/signup.php';
}
if (preg_match('~^https?://~i', $membershipsetting)) {
    $membershipurl = new moodle_url($membershipsetting);
} else {
    if ($membershipsetting[0] !== '/') {
        $membershipsetting = '/' . $membershipsetting;
    }
    $membershipurl = new moodle_url($membershipsetting);
}
$membershiplabel = trim((string)get_config('theme_bemanda', 'membershiplabel'));
if ($membershiplabel === '') {
    $membershiplabel = 'Membership';
}

// Solutions professional CTA (configurable, falls back to signup).
$prosetting = trim((string)get_config('theme_bemanda', 'prourl'));
if ($prosetting === '') {
    $prosetting = '/login/signup.php';
}
if (preg_match('~^https?://~i', $prosetting)) {
    $prourl = new moodle_url($prosetting);
} else {
    if ($prosetting[0] !== '/') {
        $prosetting = '/' . $prosetting;
    }
    $prourl = new moodle_url($prosetting);
}
$prolabel = trim((string)get_config('theme_bemanda', 'prolabel'));
if ($prolabel === '') {
    $prolabel = 'Create Professional Account';
}

// Default brand on first visit.
$defaultbrand = trim((string)get_config('theme_bemanda', 'defaultbrand'));
if ($defaultbrand !== 'solutions') {
    $defaultbrand = 'stem';
}

$sitename = format_string($SITE->fullname);

// ---------------------------------------------------------------------------
// STEM brand content (mirrors v0.1.7 design).
// ---------------------------------------------------------------------------
$grades = [
    ['Grades 1–3', 'Foundational numeracy, reading support, discovery science, and digital confidence.'],
    ['Grades 4–6', 'Fractions, geometry, scientific thinking, coding logic, and applied projects.'],
    ['Grades 7–8', 'Ratios, algebra readiness, computational thinking, and structured mastery.'],
    ['Grades 9–10', 'Algebra, geometry, biology, chemistry, and career-connected digital skills.'],
    ['Grades 11–12', 'Advanced Mathematics, Science, technology projects, and exam preparation.'],
    ['Schools', 'Structured cohorts, reporting, instructor support, and scalable deployment.'],
];
$subjects = [
    ['➗', 'Mathematics', 'Fractions, ratios, geometry, algebra readiness, and problem solving.'],
    ['💻', 'Coding', 'Logic, computational thinking, block coding, and beginner programming.'],
    ['🔬', 'Science', 'Interactive concepts, experiments, discovery, and structured practice.'],
    ['🌍', 'Social Studies', 'Geography, history, citizenship, culture, and East-African context.'],
    ['📈', 'Progress & mastery', 'Scores, completion, attempts, recommendations, and next-step guidance.'],
    ['👨‍👩‍👧', 'Parent portal', 'Child progress, activity history, mastery summaries, and reports.'],
];

// ---------------------------------------------------------------------------
// Solutions brand content (professional training; mirrors Image 1).
// ---------------------------------------------------------------------------
$procards = [
    ['Microsoft 365', 'Office 365, Teams, SharePoint, and productivity essentials.'],
    ['SharePoint', 'Document management, collaboration, and intranet skills.'],
    ['Dynamics 365', 'Business applications, CRM, and ERP fundamentals.'],
    ['ISO Training', 'ISO 9001, management systems, compliance readiness, and quality training.'],
    ['Career Preparation', 'Interview preparation, workplace readiness, CV support, and professional growth.'],
    ['Corporate Training', 'Upskill teams with structured programs, reporting, and LMS-based learning paths.'],
];

ob_start();
?>
<div class="bemanda-brands" data-default-brand="<?php echo s($defaultbrand); ?>">

    <!-- Centered brand toggle -->
    <div class="bemanda-toggle" role="tablist" aria-label="Choose brand">
        <button type="button" class="bemanda-toggle__btn" data-brand="solutions" role="tab">Bemanda Solutions</button>
        <button type="button" class="bemanda-toggle__btn" data-brand="stem" role="tab">BemandaSTEM</button>
    </div>

    <!-- ============================ STEM PANEL ============================ -->
    <div class="bemanda-panel bemanda-panel--stem" data-brand="stem">

        <header class="bemanda-bhead bemanda-bhead--stem">
            <div class="bemanda-bhead__inner">
                <span class="bemanda-bhead__logo">BemandaSTEM</span>
                <nav class="bemanda-bhead__nav">
                    <a href="#stem-subjects">Subjects</a>
                    <a href="#stem-grades">Grades</a>
                    <a href="#stem-why">Parents</a>
                    <a href="#stem-grades">Schools</a>
                </nav>
                <a class="bemanda-btn bemanda-btn--membership bemanda-bhead__cta" href="<?php echo $membershipurl; ?>"><?php echo s($membershiplabel); ?></a>
            </div>
        </header>

        <section class="bemanda-hero">
            <div class="bemanda-hero__inner">
                <div class="bemanda-hero__text">
                    <span class="bemanda-eyebrow">K–12 learning built for mastery</span>
                    <h1 class="bemanda-hero__title">Learn, explore, and grow with <?php echo $sitename; ?></h1>
                    <p class="bemanda-hero__lead">Interactive Mathematics, Coding, Science, and Social Studies with clear progress tracking for students, parents, and schools.</p>
                    <div class="bemanda-hero__actions">
                        <a class="bemanda-btn bemanda-btn--primary" href="<?php echo $membershipurl; ?>">Explore membership</a>
                        <a class="bemanda-btn bemanda-btn--ghost" href="#stem-subjects">Browse subjects</a>
                    </div>
                </div>
                <div class="bemanda-hero__art" aria-hidden="true">
                    <span class="bemanda-hero__rocket">🚀</span>
                    <span class="bemanda-float bemanda-float--1">🧪</span>
                    <span class="bemanda-float bemanda-float--2">💻</span>
                    <span class="bemanda-float bemanda-float--3">➗</span>
                    <span class="bemanda-float bemanda-float--4">🔬</span>
                    <span class="bemanda-float bemanda-float--5">📐</span>
                    <span class="bemanda-float bemanda-float--6">🧮</span>
                    <span class="bemanda-float bemanda-float--7">🌍</span>
                    <span class="bemanda-float bemanda-float--8">⭐</span>
                </div>
            </div>
        </section>

        <div class="bemanda-trust">
            <div><strong>Personalized learning</strong>Students continue from their current skill level.</div>
            <div><strong>Mastery tracking</strong>Progress, scores, attempts, and completion in Moodle.</div>
            <div><strong>Parent visibility</strong>Parents can review learning activity and reports.</div>
        </div>

        <section class="bemanda-section" id="stem-grades">
            <div class="bemanda-section__inner">
                <div class="bemanda-section__title">
                    <h2>Choose a grade-level journey</h2>
                    <p>Start with the right learning path and build one skill at a time.</p>
                </div>
                <div class="bemanda-grid bemanda-grid--3">
                    <?php foreach ($grades as $g): ?>
                        <div class="bemanda-card bemanda-card--grade">
                            <h3><?php echo s($g[0]); ?></h3>
                            <p><?php echo s($g[1]); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="bemanda-section bemanda-section--subjects" id="stem-subjects">
            <div class="bemanda-section__inner">
                <div class="bemanda-section__title">
                    <h2>Explore subjects</h2>
                    <p>Each subject opens into Moodle courses and interactive activities.</p>
                </div>
                <div class="bemanda-grid bemanda-grid--3">
                    <?php foreach ($subjects as $subj): ?>
                        <div class="bemanda-card bemanda-card--subject">
                            <div class="bemanda-card__icon"><?php echo $subj[0]; ?></div>
                            <h3><?php echo s($subj[1]); ?></h3>
                            <p><?php echo s($subj[2]); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="bemanda-why" id="stem-why">
            <div class="bemanda-why__inner">
                <span class="bemanda-why__eyebrow">WHY BEMANDASTEM</span>
                <h2 class="bemanda-why__title">Discover how BemandaSTEM supports success for every learner</h2>
                <p class="bemanda-why__lead">BemandaSTEM gives families and teachers everything they need to personalise learning and see real results.</p>
                <div class="bemanda-why__grid">
                    <div class="bemanda-why-card">
                        <div class="bemanda-why-card__icon">🌐</div>
                        <h3>Bilingual Learning</h3>
                        <p>Switch between English and Amharic any time. Perfect for diaspora families and Ethiopian classrooms.</p>
                        <a href="#stem-subjects">Explore languages →</a>
                    </div>
                    <div class="bemanda-why-card">
                        <div class="bemanda-why-card__icon">📴</div>
                        <h3>Offline-First Activities</h3>
                        <p>Every activity works without internet. Download once and practice anywhere — on any device.</p>
                        <a href="#stem-subjects">Try an activity →</a>
                    </div>
                    <div class="bemanda-why-card">
                        <div class="bemanda-why-card__icon">👨‍👩‍👧</div>
                        <h3>Parent Portal Included</h3>
                        <p>See every skill your child has mastered. Download monthly reports. Included at no extra cost.</p>
                        <a href="#stem-subjects">See parent view →</a>
                    </div>
                    <div class="bemanda-why-card">
                        <div class="bemanda-why-card__icon">🏛️</div>
                        <h3>East-African Curriculum</h3>
                        <p>Stories and examples rooted in Ethiopian and East-African life — not imported from elsewhere.</p>
                        <a href="#stem-subjects">Browse curriculum →</a>
                    </div>
                </div>
            </div>
        </section>

        <footer class="bemanda-bfoot bemanda-bfoot--stem">
            <div class="bemanda-bfoot__inner">
                <div class="bemanda-bfoot__brand">
                    <span class="bemanda-bfoot__logo">BemandaSTEM</span>
                    <p>K–12 mastery learning for students, parents, and schools.</p>
                </div>
                <nav class="bemanda-bfoot__links">
                    <a href="#stem-subjects">Subjects</a>
                    <a href="#stem-grades">Grades</a>
                    <a href="#stem-why">Why BemandaSTEM</a>
                    <a href="<?php echo $membershipurl; ?>"><?php echo s($membershiplabel); ?></a>
                </nav>
                <div class="bemanda-bfoot__social" aria-label="Social media">
                    <a href="#" aria-label="Facebook">Facebook</a>
                    <a href="#" aria-label="Instagram">Instagram</a>
                    <a href="#" aria-label="YouTube">YouTube</a>
                    <a href="#" aria-label="Telegram">Telegram</a>
                </div>
            </div>
            <div class="bemanda-bfoot__copy">© <?php echo userdate(time(), '%Y'); ?> <?php echo $sitename; ?> — BemandaSTEM</div>
        </footer>

    </div><!-- /STEM panel -->

    <!-- ========================= SOLUTIONS PANEL ========================= -->
    <div class="bemanda-panel bemanda-panel--solutions" data-brand="solutions">

        <header class="bemanda-bhead bemanda-bhead--sol">
            <div class="bemanda-bhead__inner">
                <span class="bemanda-bhead__logo">Bemanda Solutions</span>
                <nav class="bemanda-bhead__nav">
                    <a href="#sol-catalogue">Programs</a>
                    <a href="#sol-catalogue">Certifications</a>
                    <a href="#sol-hero">Corporate</a>
                </nav>
                <a class="bemanda-btn bemanda-btn--proheadcta bemanda-bhead__cta" href="<?php echo $prourl; ?>"><?php echo s($prolabel); ?></a>
            </div>
        </header>

        <section class="bemanda-sol-hero" id="sol-hero">
            <div class="bemanda-sol-hero__inner">
                <h1>Bemanda Solutions</h1>
                <p>Professional training and certification programs for individuals, teams, and organizations ready to build practical digital skills.</p>
                <a class="bemanda-btn bemanda-btn--pro" href="<?php echo $prourl; ?>"><?php echo s($prolabel); ?></a>
            </div>
        </section>

        <section class="bemanda-section" id="sol-catalogue">
            <div class="bemanda-section__inner">
                <div class="bemanda-grid bemanda-grid--3">
                    <?php foreach ($procards as $pc): ?>
                        <div class="bemanda-card bemanda-card--pro">
                            <h3><?php echo s($pc[0]); ?></h3>
                            <p><?php echo s($pc[1]); ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <footer class="bemanda-bfoot bemanda-bfoot--sol">
            <div class="bemanda-bfoot__inner">
                <span>© <?php echo userdate(time(), '%Y'); ?> <?php echo $sitename; ?> — Bemanda Solutions</span>
                <nav><a href="#sol-catalogue">Programs</a><a href="#sol-hero">Corporate</a></nav>
            </div>
        </footer>

    </div><!-- /Solutions panel -->

    <?php
    // Moodle requires every layout to contain $OUTPUT->main_content().
    // Both brand panels are self-contained marketing pages, so we render the
    // standard front-page content into a hidden container: it satisfies the
    // layout check (and keeps the page accessible) without showing the old
    // front-page blocks on the design.
    ?>
    <div class="bemanda-maincontent-hidden" hidden aria-hidden="true" style="display:none;">
        <?php echo $OUTPUT->main_content(); ?>
    </div>

</div>
<?php
$bemandacontent = ob_get_clean();

// ---------------------------------------------------------------------------
// Standard Boost drawers layout context (gives us the real navbar + drawers).
// ---------------------------------------------------------------------------
$addblockbutton = $OUTPUT->addblockbutton();

if (isloggedin()) {
    $courseindexopen = (get_user_preferences('drawer-open-index', true) == true);
    $blockdraweropen = (get_user_preferences('drawer-open-block') == true);
} else {
    $courseindexopen = false;
    $blockdraweropen = false;
}

if (defined('BEHAT_SITE_RUNNING') && get_user_preferences('behat_keep_drawer_closed') != 1) {
    $blockdraweropen = true;
}

$extraclasses = ['uses-drawers', 'bemanda-frontpage'];
if ($courseindexopen) {
    $extraclasses[] = 'drawer-open-index';
}

$blockshtml = $OUTPUT->blocks('side-pre');
$hasblocks = (strpos($blockshtml, 'data-block=') !== false || !empty($addblockbutton));
if (!$hasblocks) {
    $blockdraweropen = false;
}
$courseindex = core_course_drawer();
if (!$courseindex) {
    $courseindexopen = false;
}

$bodyattributes = $OUTPUT->body_attributes($extraclasses);
$forceblockdraweropen = $OUTPUT->firstview_fakeblocks();

$secondarynavigation = false;
$overflow = '';
if ($PAGE->has_secondary_navigation()) {
    $tablistnav = $PAGE->has_tablist_secondary_navigation();
    $moremenu = new \core\navigation\output\more_menu($PAGE->secondarynav, 'nav-tabs', true, $tablistnav);
    $secondarynavigation = $moremenu->export_for_template($OUTPUT);
    $overflowdata = $PAGE->secondarynav->get_overflow_menu_data();
    if (!is_null($overflowdata)) {
        $overflow = $overflowdata->export_for_template($OUTPUT);
    }
}

$primary = new core\navigation\output\primary($PAGE);
$renderer = $PAGE->get_renderer('core');
$primarymenu = $primary->export_for_template($renderer);
$buildregionmainsettings = !$PAGE->include_region_main_settings_in_header_actions() && !$PAGE->has_secondary_navigation();
$regionmainsettingsmenu = $buildregionmainsettings ? $OUTPUT->region_main_settings_menu() : false;

$header = $PAGE->activityheader;
$headercontent = $header->export_for_template($renderer);

$templatecontext = [
    'sitename' => format_string($SITE->shortname, true, ['context' => context_course::instance(SITEID), "escape" => false]),
    'output' => $OUTPUT,
    'sidepreblocks' => $blockshtml,
    'hasblocks' => $hasblocks,
    'bodyattributes' => $bodyattributes,
    'courseindexopen' => $courseindexopen,
    'blockdraweropen' => $blockdraweropen,
    'courseindex' => $courseindex,
    'primarymoremenu' => $primarymenu['moremenu'],
    'secondarymoremenu' => $secondarynavigation ?: false,
    'mobileprimarynav' => $primarymenu['mobileprimarynav'],
    'usermenu' => $primarymenu['user'],
    'langmenu' => $primarymenu['lang'],
    'forceblockdraweropen' => $forceblockdraweropen,
    'regionmainsettingsmenu' => $regionmainsettingsmenu,
    'hasregionmainsettingsmenu' => !empty($regionmainsettingsmenu),
    'overflow' => $overflow,
    'headercontent' => $headercontent,
    'addblockbutton' => $addblockbutton,
    'bemandacontent' => $bemandacontent,
];

echo $OUTPUT->render_from_template('theme_bemanda/drawers', $templatecontext);
