# Bemanda Moodle Theme 0.1.1

Boost-based child theme with:
- Dedicated full-width front-page layout
- Top-right Log in button
- Configurable Membership CTA
- Standard Boost layouts retained for courses, SCORM, dashboard, and administration

## Membership CTA configuration
After activation, open:
Site administration > Appearance > Themes > Bemanda

Set:
- Membership button URL
- Membership button label

Example:
`/course/view.php?id=42`

## Installation
1. Remove any incomplete `/theme/bemanda` folder from the server.
2. Upload this ZIP through Site administration > Plugins > Install plugins.
3. Complete validation and upgrade.
4. Select Bemanda under Theme selector.
5. Purge all caches.

## Rollback
Select Boost again in Theme selector.
