<?php
defined('MOODLE_INTERNAL') || die();

$bodyattributes = $OUTPUT->body_attributes(['bemanda-frontpage']);
$siteurl = new moodle_url('/');
$loginurl = new moodle_url('/login/index.php');

$membershipsetting = trim((string)get_config('theme_bemanda', 'membershipurl'));
if ($membershipsetting === '') {
    $membershipsetting = '/login/signup.php';
}

if (preg_match('~^https?://~i', $membershipsetting)) {
    $membershipurl = new moodle_url($membershipsetting);
} else {
    if ($membershipsetting[0] !== '/') {
        $membershipsetting = '/' . $membershipsetting;
    }
    $membershipurl = new moodle_url($membershipsetting);
}

$membershiplabel = trim((string)get_config('theme_bemanda', 'membershiplabel'));
if ($membershiplabel === '') {
    $membershiplabel = 'Membership';
}
?>
<!DOCTYPE html>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <title><?php echo $OUTPUT->page_title(); ?></title>
    <link rel="shortcut icon" href="<?php echo $OUTPUT->favicon(); ?>">
    <?php echo $OUTPUT->standard_head_html(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body <?php echo $bodyattributes; ?>>
<?php echo $OUTPUT->standard_top_of_body_html(); ?>

<header class="bemanda-site-header">
    <div class="bemanda-site-header__inner">
        <a class="bemanda-site-brand" href="<?php echo $siteurl; ?>">
            <?php echo format_string($SITE->fullname); ?>
        </a>

        <div class="bemanda-site-actions">
            <?php if (isloggedin() && !isguestuser()): ?>
                <div class="bemanda-user-menu">
                    <?php echo $OUTPUT->user_menu(); ?>
                </div>
            <?php else: ?>
                <a class="bemanda-link-button" href="<?php echo $loginurl; ?>">
                    Log in
                </a>

                <a class="bemanda-membership-button" href="<?php echo $membershipurl; ?>">
                    <?php echo s($membershiplabel); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main id="page" class="bemanda-frontpage-shell">
    <div id="page-content" class="bemanda-frontpage-content">
        <div id="region-main-box">
            <section id="region-main" aria-label="<?php echo get_string('content'); ?>">
                <?php echo $OUTPUT->main_content(); ?>
            </section>
        </div>
    </div>
</main>

<footer class="bemanda-site-footer">
    <div class="bemanda-site-footer__inner">
        <div><?php echo format_string($SITE->fullname); ?></div>
        <div>&copy; <?php echo date('Y'); ?> Bemanda</div>
    </div>
</footer>

<?php echo $OUTPUT->standard_after_main_region_html(); ?>
<?php echo $OUTPUT->standard_end_of_body_html(); ?>
</body>
</html>
