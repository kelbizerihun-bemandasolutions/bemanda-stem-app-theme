<?php
// Bemanda front-page layout.
// Based on Boost's drawers layout so the full Moodle navigation (primary nav,
// user menu, My courses, Site administration, edit mode, drawers) works exactly
// as in Boost. Our custom BemandaSTEM front-page design is injected into the
// main content region.

defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir . '/behat/lib.php');
require_once($CFG->dirroot . '/course/lib.php');

// ---------------------------------------------------------------------------
// Build our custom front-page markup (hero, grades, subjects, membership).
// ---------------------------------------------------------------------------
$siteurl = new moodle_url('/');
$loginurl = new moodle_url('/login/index.php');

$membershipsetting = trim((string)get_config('theme_bemanda', 'membershipurl'));
if ($membershipsetting === '') {
    $membershipsetting = '/login/signup.php';
}
if (preg_match('~^https?://~i', $membershipsetting)) {
    $membershipurl = new moodle_url($membershipsetting);
} else {
    if ($membershipsetting[0] !== '/') {
        $membershipsetting = '/' . $membershipsetting;
    }
    $membershipurl = new moodle_url($membershipsetting);
}
$membershiplabel = trim((string)get_config('theme_bemanda', 'membershiplabel'));
if ($membershiplabel === '') {
    $membershiplabel = 'Membership';
}

$grades = [
    ['Grades 1–3', 'Foundational numeracy, reading support, discovery science, and digital confidence.'],
    ['Grades 4–6', 'Fractions, geometry, scientific thinking, coding logic, and applied projects.'],
    ['Grades 7–8', 'Ratios, algebra readiness, computational thinking, and structured mastery.'],
    ['Grades 9–10', 'Algebra, geometry, biology, chemistry, and career-connected digital skills.'],
    ['Grades 11–12', 'Advanced Mathematics, Science, technology projects, and exam preparation.'],
    ['Schools', 'Structured cohorts, reporting, instructor support, and scalable deployment.'],
];
$subjects = [
    ['➗', 'Mathematics', 'Fractions, ratios, geometry, algebra readiness, and problem solving.'],
    ['💻', 'Coding', 'Logic, computational thinking, block coding, and beginner programming.'],
    ['🔬', 'Science', 'Interactive concepts, experiments, discovery, and structured practice.'],
    ['🌍', 'Social Studies', 'Geography, history, citizenship, culture, and East-African context.'],
    ['📈', 'Progress & mastery', 'Scores, completion, attempts, recommendations, and next-step guidance.'],
    ['👨‍👩‍👧', 'Parent portal', 'Child progress, activity history, mastery summaries, and reports.'],
];

$sitename = format_string($SITE->fullname);

ob_start();
?>
<div class="bemanda-frontpage-design">

    <section class="bemanda-hero">
        <div class="bemanda-hero__inner">
            <div class="bemanda-hero__text">
                <span class="bemanda-eyebrow">K–12 learning built for mastery</span>
                <h1 class="bemanda-hero__title">Learn, explore, and grow with <?php echo $sitename; ?></h1>
                <p class="bemanda-hero__lead">Interactive Mathematics, Coding, Science, and Social Studies with clear progress tracking for students, parents, and schools.</p>
                <div class="bemanda-hero__actions">
                    <a class="bemanda-btn bemanda-btn--primary" href="#bemanda-membership">Explore membership</a>
                    <a class="bemanda-btn bemanda-btn--ghost" href="#bemanda-subjects">Browse subjects</a>
                </div>
            </div>
            <div class="bemanda-hero__art" aria-hidden="true">
                <span class="bemanda-hero__rocket">🚀</span>
                <span class="bemanda-hero__icons">🧪 💻 ➗</span>
            </div>
        </div>
    </section>

    <div class="bemanda-trust">
        <div><strong>Personalized learning</strong>Students continue from their current skill level.</div>
        <div><strong>Mastery tracking</strong>Progress, scores, attempts, and completion in Moodle.</div>
        <div><strong>Parent visibility</strong>Parents can review learning activity and reports.</div>
    </div>

    <section class="bemanda-section" id="bemanda-grades">
        <div class="bemanda-section__inner">
            <div class="bemanda-section__title">
                <h2>Choose a grade-level journey</h2>
                <p>Start with the right learning path and build one skill at a time.</p>
            </div>
            <div class="bemanda-grid bemanda-grid--3">
                <?php foreach ($grades as $g): ?>
                    <div class="bemanda-card bemanda-card--grade">
                        <h3><?php echo s($g[0]); ?></h3>
                        <p><?php echo s($g[1]); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="bemanda-section bemanda-section--subjects" id="bemanda-subjects">
        <div class="bemanda-section__inner">
            <div class="bemanda-section__title">
                <h2>Explore subjects</h2>
                <p>Each subject opens into Moodle courses and interactive activities.</p>
            </div>
            <div class="bemanda-grid bemanda-grid--3">
                <?php foreach ($subjects as $subj): ?>
                    <div class="bemanda-card bemanda-card--subject">
                        <div class="bemanda-card__icon"><?php echo $subj[0]; ?></div>
                        <h3><?php echo s($subj[1]); ?></h3>
                        <p><?php echo s($subj[2]); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <section class="bemanda-section bemanda-moodle-content">
        <div class="bemanda-section__inner">
            <?php echo $OUTPUT->main_content(); ?>
        </div>
    </section>

    <section class="bemanda-membership-band" id="bemanda-membership">
        <div class="bemanda-membership-box">
            <div class="bemanda-membership-box__text">
                <h2>Choose the right membership</h2>
                <p>Review plan features before creating an account. After payment, Moodle automatically assigns the correct cohort and learning access.</p>
            </div>
            <div class="bemanda-price-card">
                <div class="bemanda-price-card__label">FAMILY PLAN</div>
                <div class="bemanda-price-card__price">$14.99<span> / month</span></div>
                <p>Includes selected STEM courses, mastery tracking, and parent progress visibility.</p>
                <a class="bemanda-btn bemanda-btn--membership" href="<?php echo $membershipurl; ?>"><?php echo s($membershiplabel); ?></a>
            </div>
        </div>
    </section>

</div>
<?php
$bemandacontent = ob_get_clean();

// ---------------------------------------------------------------------------
// Standard Boost drawers layout context (gives us the real navbar + drawers).
// ---------------------------------------------------------------------------
$addblockbutton = $OUTPUT->addblockbutton();

if (isloggedin()) {
    $courseindexopen = (get_user_preferences('drawer-open-index', true) == true);
    $blockdraweropen = (get_user_preferences('drawer-open-block') == true);
} else {
    $courseindexopen = false;
    $blockdraweropen = false;
}

if (defined('BEHAT_SITE_RUNNING') && get_user_preferences('behat_keep_drawer_closed') != 1) {
    $blockdraweropen = true;
}

$extraclasses = ['uses-drawers', 'bemanda-frontpage'];
if ($courseindexopen) {
    $extraclasses[] = 'drawer-open-index';
}

$blockshtml = $OUTPUT->blocks('side-pre');
$hasblocks = (strpos($blockshtml, 'data-block=') !== false || !empty($addblockbutton));
if (!$hasblocks) {
    $blockdraweropen = false;
}
$courseindex = core_course_drawer();
if (!$courseindex) {
    $courseindexopen = false;
}

$bodyattributes = $OUTPUT->body_attributes($extraclasses);
$forceblockdraweropen = $OUTPUT->firstview_fakeblocks();

$secondarynavigation = false;
$overflow = '';
if ($PAGE->has_secondary_navigation()) {
    $tablistnav = $PAGE->has_tablist_secondary_navigation();
    $moremenu = new \core\navigation\output\more_menu($PAGE->secondarynav, 'nav-tabs', true, $tablistnav);
    $secondarynavigation = $moremenu->export_for_template($OUTPUT);
    $overflowdata = $PAGE->secondarynav->get_overflow_menu_data();
    if (!is_null($overflowdata)) {
        $overflow = $overflowdata->export_for_template($OUTPUT);
    }
}

$primary = new core\navigation\output\primary($PAGE);
$renderer = $PAGE->get_renderer('core');
$primarymenu = $primary->export_for_template($renderer);
$buildregionmainsettings = !$PAGE->include_region_main_settings_in_header_actions() && !$PAGE->has_secondary_navigation();
$regionmainsettingsmenu = $buildregionmainsettings ? $OUTPUT->region_main_settings_menu() : false;

$header = $PAGE->activityheader;
$headercontent = $header->export_for_template($renderer);

$templatecontext = [
    'sitename' => format_string($SITE->shortname, true, ['context' => context_course::instance(SITEID), "escape" => false]),
    'output' => $OUTPUT,
    'sidepreblocks' => $blockshtml,
    'hasblocks' => $hasblocks,
    'bodyattributes' => $bodyattributes,
    'courseindexopen' => $courseindexopen,
    'blockdraweropen' => $blockdraweropen,
    'courseindex' => $courseindex,
    'primarymoremenu' => $primarymenu['moremenu'],
    'secondarymoremenu' => $secondarynavigation ?: false,
    'mobileprimarynav' => $primarymenu['mobileprimarynav'],
    'usermenu' => $primarymenu['user'],
    'langmenu' => $primarymenu['lang'],
    'forceblockdraweropen' => $forceblockdraweropen,
    'regionmainsettingsmenu' => $regionmainsettingsmenu,
    'hasregionmainsettingsmenu' => !empty($regionmainsettingsmenu),
    'overflow' => $overflow,
    'headercontent' => $headercontent,
    'addblockbutton' => $addblockbutton,
    // Our custom front-page design, injected into the main region.
    'bemandacontent' => $bemandacontent,
];

echo $OUTPUT->render_from_template('theme_bemanda/drawers', $templatecontext);
