<?php
$string['pluginname'] = 'Bemanda';
$string['configtitle'] = 'Bemanda settings';
$string['frontpagesettings'] = 'Front page';
$string['choosereadme'] = 'Bemanda is a Boost-based theme with a dedicated full-width front-page layout and the standard Moodle navigation retained.';
$string['privacy:metadata'] = 'The Bemanda theme does not store personal data.';

$string['membershipurl'] = 'Membership button URL';
$string['membershipurl_desc'] = 'Enter a full URL or a Moodle-relative URL, such as /course/view.php?id=42.';
$string['membershiplabel'] = 'Membership button label';
$string['membershiplabel_desc'] = 'Text displayed in the membership call-to-action button.';
