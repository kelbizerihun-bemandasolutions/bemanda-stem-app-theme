# Bemanda Moodle Theme 0.1.8

Boost-based child theme. The Home page is a **two-brand marketing front page**
with a centered toggle. Moodle's real navigation (navbar, profile menu, My
courses, Site administration, edit mode, drawers) is retained on both brands.

## What changed in 0.1.8
- **Two brand panels with a centered toggle.** Below Moodle's native navbar a
  centered pill toggle switches between two self-contained marketing panels:
  - **BemandaSTEM** — the v0.1.7 K-12 design (hero, grade journeys, subject
    cards, $14.99 Family Plan membership band) plus its own brand header (logo,
    nav, membership CTA top-right) and footer.
  - **Bemanda Solutions** — professional training: dark-blue hero, "Create
    Professional Account" CTA, and a six-card catalogue (Microsoft 365,
    SharePoint, Dynamics 365, ISO Training, Career Preparation, Corporate
    Training), with its own header and footer.
- **Client-side switch, no reload.** Small inline script in the drawers
  template shows one panel at a time and remembers the choice in a cookie
  (`bemanda_brand`, 180 days). First-visit default is set in theme settings.
- **Removed the old `main_content()` prototype** from the front page. Both
  panels are now self-contained; courses are reachable via the native nav and
  the panel CTAs.
- New settings: Solutions button URL/label and Default brand.

## Earlier history
- 0.1.7 Full-width front page (breakout from Boost's centered column).
- 0.1.6 Fixed settings "Section error!"; restored native nav via drawers layout.
- 0.1.4 Renderer factory + core_renderer fix.

## Configure / settings
Site administration > Appearance > Themes > Bemanda > Settings (Front page tab):
- Membership button URL + label (BemandaSTEM CTA)
- Solutions button URL + label (Bemanda Solutions CTA)
- Default brand (which panel shows on first visit)

The membership CTA is intended to point at your pricing page (built separately).

## Editing front-page text
Brand content is in `layout/frontpage.php` (the `$grades`, `$subjects`, and
`$procards` arrays plus the hero markup). Colors and spacing are in
`scss/post.scss`, all scoped to `body.bemanda-frontpage`.

## Installation
1. Upload this ZIP via Site administration > Plugins > Install plugins (it
   upgrades the existing Bemanda).
2. Complete validation and upgrade.
3. Ensure Bemanda is selected in the Theme selector.
4. Purge all caches (Site administration > Development > Purge caches).

## Rollback
Select Boost again in the Theme selector.
