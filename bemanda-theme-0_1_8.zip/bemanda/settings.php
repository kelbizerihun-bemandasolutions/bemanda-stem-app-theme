<?php
defined('MOODLE_INTERNAL') || die();

// The Bemanda theme settings page.
// Create the settings page object and a tab, then add our options to it.
// (Clicking "Configure" loads this file; without creating $settings and a
// page, Moodle raises error/admin/sectionerror.)

if ($ADMIN->fulltree) {

    $settings = new theme_boost_admin_settingspage_tabs(
        'themesettingbemanda',
        get_string('configtitle', 'theme_bemanda')
    );

    $page = new admin_settingpage(
        'theme_bemanda_frontpage',
        get_string('frontpagesettings', 'theme_bemanda')
    );

    // Membership button URL.
    $page->add(new admin_setting_configtext(
        'theme_bemanda/membershipurl',
        get_string('membershipurl', 'theme_bemanda'),
        get_string('membershipurl_desc', 'theme_bemanda'),
        '/login/signup.php',
        PARAM_RAW_TRIMMED
    ));

    // Membership button label.
    $page->add(new admin_setting_configtext(
        'theme_bemanda/membershiplabel',
        get_string('membershiplabel', 'theme_bemanda'),
        get_string('membershiplabel_desc', 'theme_bemanda'),
        'Membership',
        PARAM_TEXT
    ));

    // Bemanda Solutions (professional) button URL.
    $page->add(new admin_setting_configtext(
        'theme_bemanda/prourl',
        get_string('prourl', 'theme_bemanda'),
        get_string('prourl_desc', 'theme_bemanda'),
        '/login/signup.php',
        PARAM_RAW_TRIMMED
    ));

    // Bemanda Solutions (professional) button label.
    $page->add(new admin_setting_configtext(
        'theme_bemanda/prolabel',
        get_string('prolabel', 'theme_bemanda'),
        get_string('prolabel_desc', 'theme_bemanda'),
        'Create Professional Account',
        PARAM_TEXT
    ));

    // Default brand shown on first visit.
    $page->add(new admin_setting_configselect(
        'theme_bemanda/defaultbrand',
        get_string('defaultbrand', 'theme_bemanda'),
        get_string('defaultbrand_desc', 'theme_bemanda'),
        'stem',
        [
            'stem' => 'BemandaSTEM',
            'solutions' => 'Bemanda Solutions',
        ]
    ));

    $settings->add($page);
}
