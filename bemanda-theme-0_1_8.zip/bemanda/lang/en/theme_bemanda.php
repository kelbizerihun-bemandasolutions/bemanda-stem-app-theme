<?php
$string['pluginname'] = 'Bemanda';
$string['configtitle'] = 'Bemanda settings';
$string['frontpagesettings'] = 'Front page';
$string['choosereadme'] = 'Bemanda is a Boost-based theme with a dedicated full-width front-page layout and the standard Moodle navigation retained.';
$string['privacy:metadata'] = 'The Bemanda theme does not store personal data.';

$string['membershipurl'] = 'Membership button URL';
$string['membershipurl_desc'] = 'Enter a full URL or a Moodle-relative URL, such as /course/view.php?id=42.';
$string['membershiplabel'] = 'Membership button label';
$string['membershiplabel_desc'] = 'Text displayed in the membership call-to-action button.';

$string['prourl'] = 'Solutions button URL';
$string['prourl_desc'] = 'Bemanda Solutions (professional) call-to-action URL. Full or Moodle-relative.';
$string['prolabel'] = 'Solutions button label';
$string['prolabel_desc'] = 'Text displayed in the Bemanda Solutions call-to-action button.';
$string['defaultbrand'] = 'Default brand';
$string['defaultbrand_desc'] = 'Which brand panel shows on a visitor\'s first load. Their later choice is remembered.';
