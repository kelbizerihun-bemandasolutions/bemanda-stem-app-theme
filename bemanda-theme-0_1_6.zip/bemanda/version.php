<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'theme_bemanda';
$plugin->version   = 2026062306;
$plugin->requires  = 2024100700;
$plugin->maturity  = MATURITY_ALPHA;
$plugin->release   = '0.1.6';
