# Bemanda Moodle Theme 0.1.6

Boost-based child theme. The Home page shows the custom BemandaSTEM design
(hero, grade journeys, subject cards, membership band) **below Moodle's real
navigation bar**, so the profile menu, My courses, Site administration, edit
mode, drawers, and course index all work normally.

## What changed in 0.1.6
1. Fixed the "Section error!" when clicking Configure.
   - `settings.php` now creates the settings page object
     (`theme_boost_admin_settingspage_tabs` + `admin_settingpage`) before
     adding options. The previous version called `$settings->add()` without
     creating `$settings`, which triggered error/admin/sectionerror.
   - Added the `configtitle` and `frontpagesettings` language strings.
2. Restored the native Moodle navigation.
   - The front page no longer uses a hand-built static header. It is now based
     on Boost's `drawers` layout, so it renders Moodle's real navbar, user
     menu, drawers, and the standard end-of-body JavaScript.
   - `layout/frontpage.php` builds the standard drawers template context and
     renders `theme_bemanda/drawers`.
   - `templates/drawers.mustache` is Boost's drawers template with one line
     changed: the main content region now outputs our front-page design
     (which itself still includes Moodle's front-page content via main_content).
3. `config.php` front-page layout now matches Boost (regions `side-pre`).
4. Kept the renderer fix from 0.1.4 (renderer factory + core_renderer).

## Configure / settings
Site administration > Appearance > Themes > Bemanda > Settings (Front page tab):
- Membership button URL (full URL or Moodle-relative, e.g. /course/view.php?id=42)
- Membership button label

## Editing front-page text
Hero, grade, and subject text is in `layout/frontpage.php` (the `$grades` and
`$subjects` arrays and the hero markup). Colors and spacing are in
`scss/post.scss` (all rules scoped to `body.bemanda-frontpage`).

## Installation
1. Uninstall the previous Bemanda version (Site administration > Plugins >
   Plugins overview > Bemanda > Uninstall), or just upload over it and run the
   upgrade.
2. Upload this ZIP via Site administration > Plugins > Install plugins.
3. Complete validation and upgrade.
4. Select Bemanda in the Theme selector if not already selected.
5. Purge all caches (Site administration > Development > Purge caches).

## Rollback
Select Boost again in the Theme selector.
