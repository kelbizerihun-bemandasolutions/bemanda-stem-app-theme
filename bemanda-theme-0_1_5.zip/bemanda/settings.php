<?php
defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {
    $settings->add(new admin_setting_configtext(
        'theme_bemanda/membershipurl',
        get_string('membershipurl', 'theme_bemanda'),
        get_string('membershipurl_desc', 'theme_bemanda'),
        '/login/signup.php',
        PARAM_RAW_TRIMMED
    ));

    $settings->add(new admin_setting_configtext(
        'theme_bemanda/membershiplabel',
        get_string('membershiplabel', 'theme_bemanda'),
        get_string('membershiplabel_desc', 'theme_bemanda'),
        'Membership',
        PARAM_TEXT
    ));
}
