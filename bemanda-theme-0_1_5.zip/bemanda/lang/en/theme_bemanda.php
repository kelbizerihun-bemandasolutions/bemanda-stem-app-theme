<?php
$string['pluginname'] = 'Bemanda';
$string['choosereadme'] = 'Bemanda is a Boost-based theme with a dedicated full-width front-page layout.';
$string['privacy:metadata'] = 'The Bemanda theme does not store personal data.';

$string['membershipurl'] = 'Membership button URL';
$string['membershipurl_desc'] = 'Enter a full URL or a Moodle-relative URL, such as /course/view.php?id=42.';
$string['membershiplabel'] = 'Membership button label';
$string['membershiplabel_desc'] = 'Text displayed in the top-right membership call-to-action button.';
