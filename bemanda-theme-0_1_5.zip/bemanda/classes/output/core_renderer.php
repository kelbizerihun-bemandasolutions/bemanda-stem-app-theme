<?php
namespace theme_bemanda\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Core renderer for the Bemanda child theme.
 *
 * Extends Boost so inherited Boost layouts and templates have access to
 * Boost-specific renderer methods.
 */
class core_renderer extends \theme_boost\output\core_renderer {
}
