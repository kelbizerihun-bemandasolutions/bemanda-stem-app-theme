<?php
defined('MOODLE_INTERNAL') || die();

$bodyattributes = $OUTPUT->body_attributes(['bemanda-frontpage']);
$siteurl = new moodle_url('/');
$loginurl = new moodle_url('/login/index.php');

// Membership URL setting.
$membershipsetting = trim((string)get_config('theme_bemanda', 'membershipurl'));
if ($membershipsetting === '') {
    $membershipsetting = '/login/signup.php';
}
if (preg_match('~^https?://~i', $membershipsetting)) {
    $membershipurl = new moodle_url($membershipsetting);
} else {
    if ($membershipsetting[0] !== '/') {
        $membershipsetting = '/' . $membershipsetting;
    }
    $membershipurl = new moodle_url($membershipsetting);
}

$membershiplabel = trim((string)get_config('theme_bemanda', 'membershiplabel'));
if ($membershiplabel === '') {
    $membershiplabel = 'Membership';
}

// Grade journeys.
$grades = [
    ['Grades 1–3', 'Foundational numeracy, reading support, discovery science, and digital confidence.'],
    ['Grades 4–6', 'Fractions, geometry, scientific thinking, coding logic, and applied projects.'],
    ['Grades 7–8', 'Ratios, algebra readiness, computational thinking, and structured mastery.'],
    ['Grades 9–10', 'Algebra, geometry, biology, chemistry, and career-connected digital skills.'],
    ['Grades 11–12', 'Advanced Mathematics, Science, technology projects, and exam preparation.'],
    ['Schools', 'Structured cohorts, reporting, instructor support, and scalable deployment.'],
];

// Subjects: [emoji, title, description].
$subjects = [
    ['➗', 'Mathematics', 'Fractions, ratios, geometry, algebra readiness, and problem solving.'],
    ['💻', 'Coding', 'Logic, computational thinking, block coding, and beginner programming.'],
    ['🔬', 'Science', 'Interactive concepts, experiments, discovery, and structured practice.'],
    ['🌍', 'Social Studies', 'Geography, history, citizenship, culture, and East-African context.'],
    ['📈', 'Progress & mastery', 'Scores, completion, attempts, recommendations, and next-step guidance.'],
    ['👨‍👩‍👧', 'Parent portal', 'Child progress, activity history, mastery summaries, and reports.'],
];
?>
<!DOCTYPE html>
<html <?php echo $OUTPUT->htmlattributes(); ?>>
<head>
    <meta charset="utf-8">
    <title><?php echo $OUTPUT->page_title(); ?></title>
    <link rel="shortcut icon" href="<?php echo $OUTPUT->favicon(); ?>">
    <?php echo $OUTPUT->standard_head_html(); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body <?php echo $bodyattributes; ?>>
<?php echo $OUTPUT->standard_top_of_body_html(); ?>

<header class="bemanda-site-header">
    <div class="bemanda-site-header__inner">
        <a class="bemanda-site-brand" href="<?php echo $siteurl; ?>">
            <?php echo format_string($SITE->fullname); ?>
        </a>

        <div class="bemanda-site-actions">
            <?php if (isloggedin() && !isguestuser()): ?>
                <div class="bemanda-user-menu">
                    <?php echo $OUTPUT->user_menu(); ?>
                </div>
            <?php else: ?>
                <a class="bemanda-link-button" href="<?php echo $loginurl; ?>">Log in</a>
                <a class="bemanda-membership-button" href="<?php echo $membershipurl; ?>"><?php echo s($membershiplabel); ?></a>
            <?php endif; ?>
        </div>
    </div>
</header>

<main id="page" class="bemanda-frontpage-shell">

    <!-- HERO -->
    <section class="bemanda-hero">
        <div class="bemanda-hero__inner">
            <div class="bemanda-hero__text">
                <span class="bemanda-eyebrow">K–12 learning built for mastery</span>
                <h1 class="bemanda-hero__title">Learn, explore, and grow with <?php echo format_string($SITE->fullname); ?></h1>
                <p class="bemanda-hero__lead">Interactive Mathematics, Coding, Science, and Social Studies with clear progress tracking for students, parents, and schools.</p>
                <div class="bemanda-hero__actions">
                    <a class="bemanda-btn bemanda-btn--primary" href="#bemanda-membership">Explore membership</a>
                    <a class="bemanda-btn bemanda-btn--ghost" href="#bemanda-subjects">Browse subjects</a>
                </div>
            </div>
            <div class="bemanda-hero__art" aria-hidden="true">
                <span class="bemanda-hero__rocket">🚀</span>
                <span class="bemanda-hero__icons">🧪 💻 ➗</span>
            </div>
        </div>
    </section>

    <!-- TRUST -->
    <div class="bemanda-trust">
        <div><strong>Personalized learning</strong>Students continue from their current skill level.</div>
        <div><strong>Mastery tracking</strong>Progress, scores, attempts, and completion in Moodle.</div>
        <div><strong>Parent visibility</strong>Parents can review learning activity and reports.</div>
    </div>

    <!-- GRADES -->
    <section class="bemanda-section" id="bemanda-grades">
        <div class="bemanda-section__inner">
            <div class="bemanda-section__title">
                <h2>Choose a grade-level journey</h2>
                <p>Start with the right learning path and build one skill at a time.</p>
            </div>
            <div class="bemanda-grid bemanda-grid--3">
                <?php foreach ($grades as $g): ?>
                    <div class="bemanda-card bemanda-card--grade">
                        <h3><?php echo s($g[0]); ?></h3>
                        <p><?php echo s($g[1]); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- SUBJECTS -->
    <section class="bemanda-section bemanda-section--subjects" id="bemanda-subjects">
        <div class="bemanda-section__inner">
            <div class="bemanda-section__title">
                <h2>Explore subjects</h2>
                <p>Each subject opens into Moodle courses and interactive activities.</p>
            </div>
            <div class="bemanda-grid bemanda-grid--3">
                <?php foreach ($subjects as $subj): ?>
                    <div class="bemanda-card bemanda-card--subject">
                        <div class="bemanda-card__icon"><?php echo $subj[0]; ?></div>
                        <h3><?php echo s($subj[1]); ?></h3>
                        <p><?php echo s($subj[2]); ?></p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- MOODLE FRONT-PAGE CONTENT (course list, custom HTML, front-page blocks) -->
    <section class="bemanda-section bemanda-moodle-content">
        <div class="bemanda-section__inner">
            <div id="page-content">
                <div id="region-main-box">
                    <section id="region-main" aria-label="<?php echo get_string('content'); ?>">
                        <?php echo $OUTPUT->main_content(); ?>
                    </section>
                </div>
            </div>
        </div>
    </section>

    <!-- MEMBERSHIP BAND -->
    <section class="bemanda-membership-band" id="bemanda-membership">
        <div class="bemanda-membership-box">
            <div class="bemanda-membership-box__text">
                <h2>Choose the right membership</h2>
                <p>Review plan features before creating an account. After payment, Moodle automatically assigns the correct cohort and learning access.</p>
            </div>
            <div class="bemanda-price-card">
                <div class="bemanda-price-card__label">FAMILY PLAN</div>
                <div class="bemanda-price-card__price">$14.99<span> / month</span></div>
                <p>Includes selected STEM courses, mastery tracking, and parent progress visibility.</p>
                <a class="bemanda-btn bemanda-btn--membership" href="<?php echo $membershipurl; ?>"><?php echo s($membershiplabel); ?></a>
            </div>
        </div>
    </section>

</main>

<footer class="bemanda-site-footer">
    <div class="bemanda-site-footer__inner">
        <div><?php echo format_string($SITE->fullname); ?></div>
        <div>&copy; <?php echo date('Y'); ?> Bemanda</div>
    </div>
</footer>

<?php echo $OUTPUT->standard_end_of_body_html(); ?>
</body>
</html>
