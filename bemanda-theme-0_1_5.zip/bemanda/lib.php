<?php
defined('MOODLE_INTERNAL') || die();

function theme_bemanda_get_main_scss_content($theme) {
    global $CFG;

    $scss = '';
    $boostpreset = $CFG->dirroot . '/theme/boost/scss/preset/default.scss';

    if (is_readable($boostpreset)) {
        $scss .= file_get_contents($boostpreset);
    }

    $postfile = __DIR__ . '/scss/post.scss';
    if (is_readable($postfile)) {
        $scss .= "\n" . file_get_contents($postfile);
    }

    return $scss;
}
