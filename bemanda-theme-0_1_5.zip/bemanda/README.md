# Bemanda Moodle Theme 0.1.5

Boost-based child theme with a dedicated, fully designed BemandaSTEM front page:
- Hero section with call-to-action buttons
- Trust bar
- Grade-level journey cards (Grades 1–3 … Schools)
- Subject cards (Mathematics, Coding, Science, Social Studies, Progress, Parent portal)
- Embedded Moodle front-page content region (course list / custom HTML still appear)
- Membership band with a Family Plan price card
- Top-right Log in button and configurable Membership CTA
- Standard Boost layouts retained for courses, SCORM, dashboard, and administration

## What changed in 0.1.5
- Added the full front-page design (hero, trust bar, grades, subjects, membership band)
  directly in `layout/frontpage.php`, matching the approved prototype.
- Added matching styles to `scss/post.scss`, all scoped under `body.bemanda-frontpage`
  so course, dashboard, and admin pages keep normal Boost styling.
- Kept the 0.1.4 white-screen fix intact (renderer factory + core_renderer pair).

## Why earlier versions showed a white screen
A Boost child theme needs BOTH of these together for `$OUTPUT` to expose Boost
renderer methods inside a custom layout:
- `$THEME->rendererfactory = 'theme_overridden_renderer_factory';` in `config.php`
- a `theme_bemanda\output\core_renderer` class that extends Boost's core renderer
Versions 0.1.1–0.1.3 had at most one half of that pair, so Boost methods were
missing and the page fatally errored. 0.1.4 added the second half; 0.1.5 keeps it.

## Membership CTA configuration
After activation, open:
Site administration > Appearance > Themes > Bemanda

Set:
- Membership button URL (full URL, or Moodle-relative like `/course/view.php?id=42`)
- Membership button label

## Installation
1. Remove any incomplete `/theme/bemanda` folder from the server.
2. Upload this ZIP through Site administration > Plugins > Install plugins.
3. Complete validation and upgrade.
4. Select Bemanda under Theme selector.
5. Purge all caches (Site administration > Development > Purge caches).

## Editing the front-page text
- Hero, grade, and subject text lives in `layout/frontpage.php` (top of the file,
  in the `$grades` and `$subjects` arrays and the hero markup).
- Colors and spacing live in the lower section of `scss/post.scss`.
- After editing SCSS, bump `version.php` or purge caches so Moodle recompiles.

## Rollback
Select Boost again in the Theme selector.
