# Bemanda Moodle Theme 0.1.3

Boost-based child theme with:
- Dedicated full-width front-page layout
- Top-right Log in button
- Configurable Membership CTA
- Standard Boost layouts retained for courses, SCORM, dashboard, and administration

## Membership CTA configuration
After activation, open:
Site administration > Appearance > Themes > Bemanda

Set:
- Membership button URL
- Membership button label

Example:
`/course/view.php?id=42`

## Installation
1. Remove any incomplete `/theme/bemanda` folder from the server.
2. Upload this ZIP through Site administration > Plugins > Install plugins.
3. Complete validation and upgrade.
4. Select Bemanda under Theme selector.
5. Purge all caches.

## Rollback
Select Boost again in Theme selector.

## 0.1.2 fix
Removed the post-main-region renderer call which caused `firstview_fakeblocks()` on the current Moodle 5.1 build.

## 0.1.3 fix
Added a child-theme core renderer extending Boost's renderer, ensuring inherited Boost layouts/templates can call Boost-specific methods such as `firstview_fakeblocks()`.
