<?php
defined('MOODLE_INTERNAL') || die();

$THEME->name = 'bemanda';
$THEME->parents = ['boost'];
$THEME->sheets = [];
$THEME->editor_sheets = [];
$THEME->scss = function($theme) {
    return theme_bemanda_get_main_scss_content($theme);
};

$THEME->layouts = [
    'frontpage' => [
        'file' => 'frontpage.php',
        'regions' => [],
        'defaultregion' => '',
        'options' => [
            'langmenu' => true,
            'nonavbar' => true,
            'nocourseheaderfooter' => true,
        ],
    ],
];

$THEME->enable_dock = false;
$THEME->haseditswitch = true;
$THEME->usescourseindex = true;
