<?php
namespace theme_bemanda\output;

defined('MOODLE_INTERNAL') || die();

/**
 * Bemanda core renderer.
 *
 * Inherit Boost's renderer so inherited Boost layouts/templates can use
 * Boost-specific renderer methods such as firstview_fakeblocks().
 */
class core_renderer extends \theme_boost\output\core_renderer {
}
